let x: number
let y: string
let z: boolean
let a: Date
let b: string[]

b = "Hello!" as any
b = 1234