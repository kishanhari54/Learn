class Contact {
    id;
    name;
    birthDate;
}