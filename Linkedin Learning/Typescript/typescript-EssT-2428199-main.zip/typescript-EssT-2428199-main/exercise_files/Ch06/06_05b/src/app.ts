import { formatDate } from "./utils"

const formattedDate = formatDate(new Date())
console.log(formattedDate)