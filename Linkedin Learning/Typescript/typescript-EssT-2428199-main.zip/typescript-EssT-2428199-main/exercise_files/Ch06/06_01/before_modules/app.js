function loadContent() {
    // ...
}

const formattedDate = formatDate(new Date())
console.log(formattedDate)