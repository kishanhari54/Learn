import { formatDate } from "./utils.js"

const formattedDate = formatDate(new Date())
console.log(formattedDate)